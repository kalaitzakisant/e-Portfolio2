from healthapp import app

if __name__ == "__main__":
    # debug mode for development only.
    app.run(debug=True)
